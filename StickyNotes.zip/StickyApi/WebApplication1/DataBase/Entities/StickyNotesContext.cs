﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StickyGetService.DataBase.Entities
{
    public class StickyNotesContext :DbContext
    {
        
        public DbSet<StickyNotes> stickynotes { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseNpgsql(@"User ID =StickyUser;Password=123;Server=localhost;Port=5432;Database=StickNotesAppDb;Integrated Security = true; Pooling = true;");

        }
        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
        }
        public override int SaveChanges()
        {
            ChangeTracker.DetectChanges();
            return base.SaveChanges();
        }

    }
}
