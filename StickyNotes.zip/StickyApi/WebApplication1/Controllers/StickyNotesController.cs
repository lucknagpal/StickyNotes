﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using Npgsql;
using NpgsqlTypes;
using StickyGetService.DataBase.Entities;

namespace WebApplication1.Controllers
{
   
    [ApiController]
    public class StickyNotesController : ControllerBase
    {
        private string sqlConnectionString = @"User ID =StickyUser;Password=123;Server=localhost;Port=5432;Database=StickNotesAppDb;Integrated Security = true; Pooling = true;";

        DbContextOptionsBuilder<StickyNotesContext> _optionsBuilder;
        StickyNotesContext _db;
       public StickyNotesController(StickyNotesContext db)
        {
            _db = db;
            
        }
        // GET: api/DashBoard
        [HttpGet]
        [Route("api/StickyNotes")]
        public IEnumerable<StickyNotes> Get()
        {
            return _db.stickynotes.ToList().OrderBy(p => p.createddate).Select(m => new StickyNotes
            {
                id = m.id,
                description = m.description
            }).ToList();
           
           // return _db.StickyNote.ToList();
           /* return _db.StickyNote.ToList();*/
        }

        // GET: api/DashBoard/5
        [HttpGet("{id}", Name = "Get")]
        [Route("api/StickyNotes")]
        public StickyNotes Get(int id)
        {
            
            return _db.stickynotes.Find(id);
        }

        // POST: api/DashBoard
        [HttpPost]
       
        [Route("api/StickyNotes")]
        public async Task<List<StickyNotes>> Post()
        {
            var val=0;
            string body = "";
            using (StreamReader stream = new StreamReader(Request.Body))
            {
                body = await stream.ReadToEndAsync();
               var data= JsonConvert.DeserializeObject<StickyNotes>(body);
                var sqlConnectionString = @"User ID =StickyUser;Password=123;Server=localhost;Port=5432;Database=StickNotesAppDb;Integrated Security = true; Pooling = true;";
                var conn = new NpgsqlConnection(sqlConnectionString);
                conn.Open();
                var cmdstr = "select insert_stickynote2('" + data.description +"'," + data.id + ")";
                using (var cmd = new NpgsqlCommand(cmdstr, conn))
                using (var reader = cmd.ExecuteReader()) {
                    while (reader.Read())
                    {
                        val = Int32.Parse(reader[0].ToString());
                      
                       
                        //do whatever you like
                    }
                }
                conn.Close();
               /* List<StickyNotes> list = new List<StickyNotes>();
                StickyNotes stickyNotes = new StickyNotes { id = val, description = data.description };
                list.Add(stickyNotes);*/
                return _db.stickynotes.ToList().Select(m => new StickyNotes
                {
                    id = m.id,
                    description = m.description
                }).ToList();
                //return val;

                
                
                
            }
           
                
            }
        

        

        [HttpPost]
        [Route("api/GetByName")]
        public async Task<List<StickyNotes>> GetByName()
        {
            string body = "";
            using (StreamReader stream = new StreamReader(Request.Body))
            {
               body = await stream.ReadToEndAsync();
                var data = JsonConvert.DeserializeObject<StickyNotes>(body);
                return _db.stickynotes.ToList().Where(p => p.description.Contains(data.description)).ToList();
            }

        }

        [HttpPost]
        [Route("api/DeleteStickyNote")]
        public async Task<List<StickyNotes>> DeleteStickyNote()
        {
            string body = "";
            using (StreamReader stream = new StreamReader(Request.Body))
            {
                body = await stream.ReadToEndAsync();
                var data = JsonConvert.DeserializeObject<StickyNotes>(body);
                var obj = _db.stickynotes.Find(data.id);
                 _db.stickynotes.Remove(obj);
                _db.SaveChanges();
                return _db.stickynotes.ToList();
            }

        }




       


    }
}
