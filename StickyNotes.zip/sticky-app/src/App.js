import React from "react";
import './App.css';
import  {BrowserRouter as Router,Redirect ,Route,useHistory } from 'react-router-dom'
import Notes from './Components/Notes'


function App() {
  return (
 
      <div>
          <Router>
         
          <Route exact path="/Notes" component={Notes}></Route>
         </Router>
       

      </div>
  
  )
}

export default App;
