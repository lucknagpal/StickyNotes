import React from 'react'
import { Button,Modal,Form } from 'react-bootstrap'
import $ from 'jquery';
class StickyNotes extends React.Component{
  constructor(props){
    super(props);
    
    this.state = { 
      StickyNoteId:0,
      description:'',
      showHide:false,
      tasks:[],
      TasksList:[],
      clicks : [],
      showdata:[]
    }
    this.close=this.close.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }
  
  componentDidMount() {
    debugger;
    this.getTasks();
    
  }

 

getTasks()
{
  debugger
if(this.state.TasksList.length==0)
{
   fetch("https://localhost:44364/api/StickyNotes")
  .then(response => response.json())
  .then(data => {
    this.setState({TasksList: data});
     console.log(this.state.TasksList);
    })
  .catch(error => this.setState({ error, isLoading: false }));
}
}
  
 getvals(){
  return fetch('https://localhost:44364/api/StickyNotes',
  )
  .then((response) => response.json())
  .then((responseData) => {
    debugger;
    console.log(responseData);
    return responseData;
  })
  .catch(error => console.warn(error));
}

	handleSubmit(e)
{
 
  this.setState({description:e.target.value})
  this.setState()
  var body={
    id:this.state.StickyNoteId,
    Description : e.target.value,
   
  }

  fetch("https://localhost:44364/api/StickyNotes", {
          method: 'POST',
          headers: { 'Content-Type': 'application/json; charset=utf-8'},
          body: JSON.stringify(body),
      }).then(res => res.json())
      .then((data) => {
        console.log(data[0].id);
       this.setState({StickyNoteId:data[0].id})
    
      })
      .catch(console.log)
    
}

setForm() { 
  var form = document.querySelector('form');
  form.querySelector('textarea').value = "";
}

deleteTask(data)
{
debugger;
var body={
  id:data
}

  fetch("https://localhost:44364/api/DeleteStickyNote", {
    method: 'POST',
    headers: { 'Content-Type': 'application/json; charset=utf-8'},
    body: JSON.stringify(body),
}).then(res => res.json())
.then((data) => {
  
this.setState({TasksList:data})
console.log(this.state.TasksList);
})
.catch(console.log)
}

handleSearch(e)
{
debugger;

var body={
  description:e.target.value
}

  fetch("https://localhost:44364/api/GetByName", {
    method: 'POST',
    headers: { 'Content-Type': 'application/json; charset=utf-8'},
    body: JSON.stringify(body),
}).then(res => res.json())
.then((data) => {
  
this.setState({TasksList:data})
  console.log(this.state.TasksList);
})
.catch(console.log)
}
close(){
  debugger
  fetch("https://localhost:44364/api/StickyNotes")
  .then(response => response.json())
  .then(data => {
    this.setState({TasksList: data});
    debugger
    
     console.log(this.state.TasksList);
    })
  .catch(error => this.setState({ error, isLoading: false }));
  this.setState({ showHide: !this.state.showHide })
}

handleChange(e) {
  // If you are using babel, you can use ES 6 dictionary syntax
  // let change = { [e.target.name] = e.target.value }
  let change = {}
  change[e.target.name] = e.target.value
  this.setState(change)
}

 handleModalShowHide(item) {
debugger
this.setState({ showHide: !this.state.showHide })

  if(item!=undefined)
  { this.setState({description:item.description})
this.setState({StickyNoteId:item.id})
  }else{
    
    this.setState({description:''});
this.setState({StickyNoteId:0})
  }
 
}

    render(){
      debugger;
      this.items=[];
      if( this.state.TasksList!=null && this.state.TasksList.length>0)
      {
 
  this.items = this.state.TasksList.map((item) =>

  <div>
    <button onClick={() => this.deleteTask(item.id)} class="delete">✖</button>
    <div onClick={() => this.handleModalShowHide(item)}  class="noteContent">
  <span class="task">{item.description}</span>
  <div class="date">{item.createdDate }</div>
  </div>
  </div>
 
);}
        return(
          <div>
         <div id="count"></div>
    <div className='container-fluid'>
        <header><button onClick={() => this.handleModalShowHide()}className="Add">+</button></header>
        <div className="form-group has-search">
    <span className="fa fa-search form-control-feedback"></span>
    <input type="text" onChange={(e) => this.handleSearch(e)} className="form-control" placeholder="Search"/>
  </div> 
        <Modal id="stickyNote-modal" onHide={this.close} show={this.state.showHide}>
                    <Modal.Header closeButton onClick={() => this.handleModalShowHide()}>
                    </Modal.Header>
                    <Modal.Body>
      <Form >
     <Form.Group controlId="formProjectId">
    <Form.Label hidden>Project Id</Form.Label>
    <Form.Control hidden  type="text" name="ProjectId" value={this.state.StickyNoteId}  />
  </Form.Group>

  <Form.Group controlId="formProjectTitle">
       <textarea className="form-control" value={this.state.description}  onChange={(e) => this.handleSubmit(e)}></textarea>
      </Form.Group>
</Form>


                    </Modal.Body>
                </Modal>
                
                
               
    <div >         
	
     
    {this.items}
    </div>
   
  </div>	
              </div>
  
  
  
        )
        }
}

export default StickyNotes;