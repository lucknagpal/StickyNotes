import React from 'react'
import { Button,Modal,Form } from 'react-bootstrap'
import $ from 'jquery';
import NoteList from './NoteList';
import Add from './add.svg';
class Notes extends React.Component{
    
    constructor(props){
    super(props);
    
    this.state = { 
      StickyNoteId:0,
      description:'',
      showHide:false,
      tasks:[],
      notes:[],
      clicks : [],
      showdata:[]
    }
   this.onDismiss=this.onDismiss.bind(this);
}
componentDidMount() {
    debugger
  this.getvals();
   }

addNote () {
    debugger
    var body={
      id:0,
      Description : '',
     
    }
    fetch("https://localhost:44364/api/StickyNotes", {
      method: 'POST',
      headers: { 'Content-Type': 'application/json; charset=utf-8'},
      body: JSON.stringify(body),
  }).then(res => res.json())
  .then((data) => {
   
   this.setState({notes:data});
  })
  .catch(console.log)
  };
 
  getvals(){
    return fetch('https://localhost:44364/api/StickyNotes',
    )
    .then((response) => response.json())
    .then((responseData) => {
      debugger;
     if(responseData.length>0)
     {
      this.setState({notes:responseData});
      //let data=JSON.parse(localStorage.getItem('notes')) || [{ id: 0,Description:'' }];
     }  
    //  else{
    //    let arr=this.state.notes;
    //    arr.push({ id: 0,Description:'' });
    //    this.setState({notes:arr})
    //  }
     
    })
    .catch(error => console.warn(error));
  }
  
  onDismiss(data){
    debugger
      
    
  var body={
    id:data
  }
  
    fetch("https://localhost:44364/api/DeleteStickyNote", {
      method: 'POST',
      headers: { 'Content-Type': 'application/json; charset=utf-8'},
      body: JSON.stringify(body),
  }).then(res => res.json())
  .then((data) => {
    debugger
    this.setState({notes:data})
    this.updateNotesList();
  })
  .catch(console.log)
    }



  handleSearch(e)
  {
  debugger;
  
  var body={
    description:e.target.value
  }
  
    fetch("https://localhost:44364/api/GetByName", {
      method: 'POST',
      headers: { 'Content-Type': 'application/json; charset=utf-8'},
      body: JSON.stringify(body),
  }).then(res => res.json())
  .then((data) => {
  this.setState({notes:data})
    
  })
  .catch(console.log)
  }

  updateNotesList()
  {
    debugger
    this.items=[];
    this.items = this.state.notes.map((item) =>
    <NoteList onDismiss={this.onDismiss} data={item}></NoteList>
  );
  }
    render()
    {
      debugger
       this.updateNotesList();
          return(
          
        
    <div className="container-fluid">
        <form>
          <div className="form-group mt-3">
            <input type="text" onChange={(e) => this.handleSearch(e)} className="form-control" placeholder="Search" />
          </div>
        </form>
        <div className="row">
          {this.items}
        </div>
        <div onClick={(e) => this.addNote(e)} className="footer text-center fixed-bottom p-2" id="toolbar" tabindex="0">
          <span class="text-white">  
            <img width="16px" src={Add}/> Add
          </span> 
        </div>
    </div>
    
          );
          }
  }

  export default Notes;