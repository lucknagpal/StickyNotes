import React, { useRef } from "react";
import { Button,Modal,Form } from 'react-bootstrap'
import $ from 'jquery';
import {  BsFillCaretRightFill }  from "react-icons/bs";
import Cross from './cross.svg';
import useDraggable from "./useDraggable";
import {Redirect} from 'react-router-dom';
const DraggableCard = ({ children }) => {
  const cardRef = useRef(null);
  useDraggable(cardRef);

  return (
    <div className="" ref={cardRef}>
      {children}
    </div>
  );
};

class NoteList extends React.Component{constructor(props){
    super(props);
    
    this.state = { 
      StickyNoteId:0,
      description:'',
      showHide:false,
      tasks:[],
      TasksList:[],
      clicks : [],
      showdata:[],
     
    }
   
}


// onDismiss(data){
//   debugger
    
  
// var body={
//   id:data
// }

//   fetch("https://localhost:44364/api/DeleteStickyNote", {
//     method: 'POST',
//     headers: { 'Content-Type': 'application/json; charset=utf-8'},
//     body: JSON.stringify(body),
// }).then(res => res.json())
// .then((data) => {
//  window.location.reload();

// })
// .catch(console.log)
//   }
  
  onFocusOut(event){
   debugger
   const DivId=this.props.data.id;

   if( event.target.innerText)
   {
   const content = event.target.innerText;
    event.target.innerText = content;

    var body={
      id:DivId,
      Description : content,
     
    }
    // const json = {
    //   'id':DivId,
    //   'content':content
    // }
    this.updateNote(body);
    localStorage.setItem('notes', JSON.stringify(this.notes));
    console.log("********* updating note *********")
  }
  }

  getvals(){
     fetch('https://localhost:44364/api/StickyNotes',
    )
    .then((response) => response.json())
    .then((responseData) => {
      debugger;
      console.log(responseData);
      
    })
    .catch(error => console.warn(error));
  }

  updateNote(newValue){

    fetch("https://localhost:44364/api/StickyNotes", {
      method: 'POST',
      headers: { 'Content-Type': 'application/json; charset=utf-8'},
      body: JSON.stringify(newValue),
  }).then(res => res.json())
  .then((data) => {
    return <Redirect to='/Notes' />

  })
  .catch(console.log)


    //   this.notes=[];
    //   this.notes=JSON.parse(localStorage.getItem('notes'));
    // this.notes.forEach((note, index)=>{
    //   if(note.id== newValue.id) {
    //     this.notes[index].content = newValue.content;
    //   } 
    // });
  }

  record(event) {
    //this.recognition.start();
  }
    render(){
   debugger

    return(
      <div className="col-sm-2 mb-30">

<DraggableCard>
        <div className="note">
          <div className="note-header p-2 text-right">
          <img width="12px" onClick={(e) =>this.props.onDismiss(this.props.data.id)} src={Cross}/>
          </div>
          <div className="content" contenteditable="true" onBlur={(e) =>this.onFocusOut(e)}>
            {this.props.data.description}
          </div>
        </div> 
        </DraggableCard>
      </div>
    );
  }
}

  export default NoteList;